---
name: Add language
about: Add support for new language
title: ''
labels: ''
assignees: ''

---

<!--- vim-polyglot accepts only lightweight, maintained github-hosted vim plugins -->

**GitHub repository url**


**Is this plugin well maintained?**


**Is this plugin lightweight? (no advanced functionality, just indent and syntax support)**
